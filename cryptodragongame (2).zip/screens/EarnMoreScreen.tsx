import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Screen } from '../types';
import BalanceDisplay from '../components/BalanceDisplay';
import GlowingButton from '../components/GlowingButton';
import BannerAd from '../components/BannerAd';
import { Gift, Play, Star, ArrowLeft, LogOut } from 'lucide-react';
import ReferralProgram from '../components/ReferralProgram';

const EarnMoreScreen: React.FC = () => {
    const { setScreen, user, settings, claimDailyBonus, watchAnotherVideo, claimSpecialTask, logout } = useApp();
    const [bonusMessage, setBonusMessage] = useState<string>('');
    const [specialTaskMessage, setSpecialTaskMessage] = useState<string>('');
    const [isBonusAvailable, setIsBonusAvailable] = useState(true);
    const [cooldownTime, setCooldownTime] = useState(0);

    useEffect(() => {
        if (!user) return;
        if (user.lastDailyBonus) {
            const lastBonusDate = new Date(user.lastDailyBonus);
            const diffHours = (new Date().getTime() - lastBonusDate.getTime()) / (1000 * 60 * 60);
            setIsBonusAvailable(diffHours >= 24);
        } else {
            setIsBonusAvailable(true);
        }
    }, [user]);

    useEffect(() => {
        if (cooldownTime > 0) {
            const interval = setInterval(() => {
                setCooldownTime(prev => (prev > 0 ? prev - 1 : 0));
            }, 1000);
            return () => clearInterval(interval);
        }
    }, [cooldownTime]);

    useEffect(() => {
        if (!user) return;
        const checkCooldown = () => {
            if (user.anotherCooldownUntil) {
                const cooldownEnds = new Date(user.anotherCooldownUntil);
                const now = new Date();
                if (now < cooldownEnds) {
                    const remainingSeconds = Math.round((cooldownEnds.getTime() - now.getTime()) / 1000);
                    setCooldownTime(remainingSeconds > 0 ? remainingSeconds : 0);
                } else {
                    setCooldownTime(0);
                }
            } else {
                setCooldownTime(0);
            }
        };
        checkCooldown();
    }, [user]);

    const today = new Date().toISOString().substring(0, 10);
    const lastWatchDate = user?.lastAnotherVideoWatchDate ? new Date(user.lastAnotherVideoWatchDate).toISOString().substring(0, 10) : null;
    const videosWatched = (user && lastWatchDate === today) ? user.anotherVideosWatchedToday : 0;
    const dailyLimit = settings.dailyAnotherVideoLimit;
    const isLimitReached = videosWatched >= dailyLimit;
    const isSpecialTaskUnlocked = videosWatched >= settings.dailyAnotherVideoLimit;
    const lastClaimDate = user?.lastSpecialTaskClaim ? new Date(user.lastSpecialTaskClaim).toISOString().substring(0, 10) : null;
    const isSpecialTaskClaimedToday = lastClaimDate === today;

    const isVideoButtonDisabled = isLimitReached || cooldownTime > 0;
    
    const handleWatchVideo = async () => {
        if (isVideoButtonDisabled) return;
        const result = await watchAnotherVideo();
        if (!result.success && result.cooldown) {
            setCooldownTime(result.cooldown);
        }
    };
    
    const handleClaimSpecialTask = async () => {
        const result = await claimSpecialTask();
        setSpecialTaskMessage(result.message);
        setTimeout(() => setSpecialTaskMessage(''), 3000);
    };

    const handleDailyBonus = async () => {
        const success = await claimDailyBonus();
        if (success) {
            setBonusMessage('Bonus claimed!');
            setIsBonusAvailable(false);
        } else {
            setBonusMessage('Daily bonus already claimed.');
        }
        setTimeout(() => setBonusMessage(''), 3000);
    };
    
    let videoButtonText: string;
    if (cooldownTime > 0) {
        const minutes = Math.floor(cooldownTime / 60);
        const seconds = cooldownTime % 60;
        videoButtonText = `Next videos in ${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    } else if (isLimitReached) {
        videoButtonText = `Daily Limit Reached (${dailyLimit}/${dailyLimit})`;
    } else {
        videoButtonText = `Watch Another Video (${videosWatched}/${dailyLimit})`;
    }

    return (
        <div className="flex flex-col min-h-screen justify-between">
            <main>
                <div className="flex items-center justify-center relative my-4">
                    <button 
                        onClick={() => setScreen(Screen.HOME)}
                        className="absolute left-0 p-2 rounded-full bg-black/20 hover:bg-black/40 text-gray-300 hover:text-white transition-all duration-300"
                        aria-label="Go back to Home"
                    >
                        <ArrowLeft size={22} /> 
                    </button>
                    <div className="text-center">
                        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] font-orbitron">Earn More</h1>
                        <p className="text-gray-300">Complete tasks for extra rewards.</p>
                    </div>
                    <button 
                        onClick={logout}
                        className="absolute right-0 p-2 rounded-full bg-black/20 hover:bg-black/40 text-gray-300 hover:text-white transition-all duration-300"
                        aria-label="Logout"
                    >
                        <LogOut size={22} /> 
                    </button>
                </div>

                <BannerAd position="top" />
                
                <BalanceDisplay />
                <div className="space-y-4 my-8">
                    <GlowingButton onClick={handleWatchVideo} disabled={isVideoButtonDisabled} Icon={Play}>
                        {videoButtonText}
                    </glowingButton>
                    
                    {isSpecialTaskUnlocked && (
                        <div className="relative">
                            <GlowingButton 
                                onClick={handleClaimSpecialTask} 
                                variant="secondary" 
                                Icon={Star}
                                disabled={isSpecialTaskClaimedToday}
                            >
                                {isSpecialTaskClaimedToday ? 'Special Task Claimed Today' : `Claim ${settings.specialRewardCoins} Coins`}
                            </glowingButton>
                             {specialTaskMessage && <p className={`text-center text-sm mt-2 ${specialTaskMessage.includes('claimed') || specialTaskMessage.includes('unlocked') ? 'text-green-400' : 'text-yellow-400'}`}>{specialTaskMessage}</p>}
                        </div>
                    )}
                    
                    <div className="relative">
                        <GlowingButton 
                            onClick={handleDailyBonus} 
                            Icon={Gift} 
                            disabled={!isBonusAvailable}
                            className={`
                                from-[var(--accent)] to-[var(--secondary)] disabled:from-gray-600 disabled:to-gray-700 disabled:opacity-50 disabled:shadow-none
                                shadow-[0_0_15px_var(--glow-2)] hover:shadow-[0_0_25px_var(--glow-2)]
                                focus:ring-[var(--accent)]/50
                            `}
                        >
                            {isBonusAvailable ? 'Claim Daily Bonus' : 'Bonus Claimed'}
                        </glowingButton>
                        {bonusMessage && <p className="text-center text-sm mt-2 text-[var(--accent)]">{bonusMessage}</p>}
                    </div>
                </div>

                <ReferralProgram />

            </main>
            <footer className="space-y-4 mt-8">
                <BannerAd position="bottom" />
            </footer>
        </div>
    );
};

export default EarnMoreScreen;
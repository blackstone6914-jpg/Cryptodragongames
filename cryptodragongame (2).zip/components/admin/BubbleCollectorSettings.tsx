
import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Save } from 'lucide-react';

const Toggle: React.FC<{ enabled: boolean; onChange: (enabled: boolean) => void }> = ({ enabled, onChange }) => (
    <button
        onClick={() => onChange(!enabled)}
        className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${enabled ? 'bg-blue-600' : 'bg-gray-600'}`}
    >
        <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform duration-300 ease-in-out ${enabled ? 'translate-x-6' : 'translate-x-1'}`} />
    </button>
);

const BubbleCollectorSettings: React.FC = () => {
    const { settings, updateSettings } = useApp();
    const [enabled, setEnabled] = useState(settings.bubbleCollectorEnabled);
    const [dailyLimit, setDailyLimit] = useState(settings.dailyBubbleLimit);
    const [minCoins, setMinCoins] = useState(settings.bubbleMinCoins);
    const [maxCoins, setMaxCoins] = useState(settings.bubbleMaxCoins);
    const [frequency, setFrequency] = useState(settings.bubbleFrequencySeconds);

    const handleSave = async () => {
        await updateSettings({
            bubbleCollectorEnabled: enabled,
            dailyBubbleLimit: dailyLimit,
            bubbleMinCoins: minCoins,
            bubbleMaxCoins: maxCoins,
            bubbleFrequencySeconds: frequency,
        });
        alert('Bubble Collector settings updated!');
    };

    return (
        <div className="space-y-6">
            <h2 className="text-xl font-bold text-white font-orbitron">Bubble Collector Minigame</h2>
            
            <div className="bg-black/20 p-4 rounded-xl space-y-4">
                <h3 className="font-semibold text-gray-200">Game Status & Limits</h3>
                
                <div className="flex items-center justify-between p-2 bg-black/30 rounded-lg">
                    <label className={`font-bold text-lg ${enabled ? 'text-green-400' : 'text-red-400'}`}>
                        {enabled ? 'Bubble Minigame Enabled' : 'Bubble Minigame Disabled'}
                    </label>
                    <Toggle enabled={enabled} onChange={setEnabled} />
                </div>

                <div className={`space-y-3 transition-opacity ${!enabled ? 'opacity-50 pointer-events-none' : ''}`}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-blue-500/10">
                        <div className="space-y-2">
                            <label className="font-medium text-gray-300 text-sm">Daily Bubble Limit</label>
                            <p className="text-xs text-gray-500">Max bubbles a user can pop per day.</p>
                            <input type="number" value={dailyLimit} onChange={e => setDailyLimit(Number(e.target.value))} className="w-full bg-black/40 p-2 rounded-lg text-white" />
                        </div>
                        <div className="space-y-2">
                             <label className="font-medium text-gray-300 text-sm">Bubble Frequency (Seconds)</label>
                             <p className="text-xs text-gray-500">How often a new bubble appears.</p>
                             <input type="number" value={frequency} onChange={e => setFrequency(Number(e.target.value))} className="w-full bg-black/40 p-2 rounded-lg text-white" />
                        </div>
                         <div className="space-y-2">
                            <label className="font-medium text-gray-300 text-sm">Min Coins per Bubble</label>
                             <input type="number" value={minCoins} onChange={e => setMinCoins(Number(e.target.value))} className="w-full bg-black/40 p-2 rounded-lg text-white" />
                        </div>
                         <div className="space-y-2">
                             <label className="font-medium text-gray-300 text-sm">Max Coins per Bubble</label>
                             <input type="number" value={maxCoins} onChange={e => setMaxCoins(Number(e.target.value))} className="w-full bg-black/40 p-2 rounded-lg text-white" />
                        </div>
                    </div>
                </div>

                <button onClick={handleSave} className="w-full mt-2 flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:opacity-90 p-3 rounded-lg font-bold text-lg font-orbitron">
                    <Save size={20} />
                    Save Settings
                </button>
            </div>

            <div className="bg-black/20 p-4 rounded-xl">
                 <h3 className="font-semibold text-gray-200 mb-2">How it works:</h3>
                 <ol className="list-decimal list-inside text-sm text-gray-400 space-y-1">
                    <li>If enabled, bubbles will appear on the Home and Earn More screens.</li>
                    <li>A new bubble is generated every <span className="font-bold text-white">{frequency}</span> seconds.</li>
                    <li>When a user taps a bubble, they earn a random amount between <span className="font-bold text-white">{minCoins}</span> and <span className="font-bold text-white">{maxCoins}</span> coins.</li>
                    <li>Users can collect a maximum of <span className="font-bold text-white">{dailyLimit}</span> bubbles per day.</li>
                 </ol>
            </div>
        </div>
    );
};

export default BubbleCollectorSettings;

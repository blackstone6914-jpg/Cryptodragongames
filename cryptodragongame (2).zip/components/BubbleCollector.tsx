
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useApp } from '../context/AppContext';

interface Bubble {
    id: number;
    x: number;
    size: number;
    duration: number;
}

interface PoppedBubble {
    id: number;
    x: number;
    y: number;
    amount: number;
}

const BubbleCollector: React.FC = () => {
    const { settings, user, collectBubble } = useApp();
    const [bubbles, setBubbles] = useState<Bubble[]>([]);
    const [poppedBubbles, setPoppedBubbles] = useState<PoppedBubble[]>([]);
    const bubbleIdCounter = useRef(0);

    const createBubble = useCallback(() => {
        if (!user) return;
        const today = new Date().toISOString().substring(0, 10);
        const lastCollectionDate = user.lastBubbleCollectionDate ? new Date(user.lastBubbleCollectionDate).toISOString().substring(0, 10) : null;
        const bubblesToday = lastCollectionDate === today ? user.bubblesCollectedToday : 0;

        if (bubblesToday >= settings.dailyBubbleLimit) {
            return;
        }

        bubbleIdCounter.current += 1;
        const newBubble: Bubble = {
            id: bubbleIdCounter.current,
            x: Math.random() * 90 + 5, // % from left, avoids edges
            size: Math.random() * 30 + 30, // 30px to 60px
            duration: Math.random() * 5 + 5, // 5s to 10s
        };
        setBubbles(prev => [...prev, newBubble]);
    }, [user, settings.dailyBubbleLimit]);

    useEffect(() => {
        if (!settings.bubbleCollectorEnabled) {
            setBubbles([]); // Clear bubbles if disabled
            return;
        }

        const interval = setInterval(createBubble, settings.bubbleFrequencySeconds * 1000);
        return () => clearInterval(interval);
    }, [settings.bubbleCollectorEnabled, settings.bubbleFrequencySeconds, createBubble]);

    const handleBubbleClick = async (e: React.MouseEvent<HTMLDivElement>, bubbleId: number) => {
        e.stopPropagation();

        const result = await collectBubble();
        if (result.success && result.amount) {
            const bubbleElement = e.currentTarget;
            const rect = bubbleElement.getBoundingClientRect();
            
            setPoppedBubbles(prev => [...prev, {
                id: Date.now(),
                x: rect.left + rect.width / 2,
                y: rect.top,
                amount: result.amount as number,
            }]);

            // Add popped class for animation
            bubbleElement.classList.add('popped');
            
            // Remove after animation
            setTimeout(() => {
                setBubbles(prev => prev.filter(b => b.id !== bubbleId));
            }, 300); // match CSS animation duration
        }
    };
    
    const handleAnimationEnd = (bubbleId: number) => {
        setBubbles(prev => prev.filter(b => b.id !== bubbleId));
    };

    const handlePopAnimationEnd = (popId: number) => {
        setPoppedBubbles(prev => prev.filter(p => p.id !== popId));
    };

    if (!settings.bubbleCollectorEnabled) {
        return null;
    }

    return (
        <div id="bubble-collector-container">
            {bubbles.map(bubble => (
                <div
                    key={bubble.id}
                    className="bubble"
                    style={{
                        left: `${bubble.x}%`,
                        width: `${bubble.size}px`,
                        height: `${bubble.size}px`,
                        animationDuration: `${bubble.duration}s`,
                    }}
                    onClick={(e) => handleBubbleClick(e, bubble.id)}
                    onAnimationEnd={() => handleAnimationEnd(bubble.id)}
                />
            ))}
            {poppedBubbles.map(pop => (
                <div
                    key={pop.id}
                    className="bubble-reward"
                    style={{
                        left: `${pop.x}px`,
                        top: `${pop.y}px`,
                        transform: 'translate(-50%, -50%)',
                    }}
                    onAnimationEnd={() => handlePopAnimationEnd(pop.id)}
                >
                    +{pop.amount}
                </div>
            ))}
        </div>
    );
};

export default BubbleCollector;

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Share2, Copy, Check } from 'lucide-react';
import GlowingButton from './GlowingButton';

const ReferralProgram: React.FC = () => {
    const { user, settings, applyReferralCode } = useApp();
    const [referralCodeInput, setReferralCodeInput] = useState('');
    const [message, setMessage] = useState('');
    const [isCopied, setIsCopied] = useState(false);

    if (!settings.referralProgramEnabled || !user) {
        return null;
    }

    const handleApplyCode = async () => {
        if (!referralCodeInput.trim()) {
            setMessage('Please enter a referral code.');
            return;
        }
        const result = await applyReferralCode(referralCodeInput);
        setMessage(result.message);
        if (result.success) {
            setReferralCodeInput('');
        }
        setTimeout(() => setMessage(''), 5000); // Clear message after 5 seconds
    };

    const handleCopyToClipboard = () => {
        navigator.clipboard.writeText(user.referralCode);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
    };
    
    const handleShare = () => {
        if (navigator.share) {
             navigator.share({
                title: `${settings.appName} Referral`,
                text: `Join me on ${settings.appName} and get ${settings.refereeBonusCoins} bonus coins! Use my code: ${user.referralCode}`,
                url: `${window.location.origin}?ref=${user.referralCode}`,
            });
        } else {
            handleCopyToClipboard();
            alert('Share API not supported. Referral link copied to clipboard!');
        }
    };

    return (
        <div className="bg-black/30 p-4 rounded-2xl border border-[var(--primary)]/20 space-y-4">
            <div className="flex items-center gap-3">
                <Share2 size={24} className="text-[var(--primary)]" />
                <h3 className="text-xl font-bold text-white font-orbitron">Referral Program</h3>
            </div>
            
            <p className="text-sm text-gray-300">
                Invite friends and earn <span className="font-bold text-[var(--accent)]">{settings.referrerBonusCoins}</span> coins for each referral. Your friend gets <span className="font-bold text-[var(--accent)]">{settings.refereeBonusCoins}</span> coins too!
            </p>

            <div className="bg-black/40 p-3 rounded-xl">
                <p className="text-xs text-gray-400">Your Referral Code:</p>
                <div className="flex items-center justify-between gap-2 mt-1">
                    <p className="font-mono text-lg font-bold text-white tracking-widest">{user.referralCode}</p>
                    <div className="flex gap-2">
                        <button onClick={handleCopyToClipboard} className="p-2 bg-black/30 hover:bg-black/50 rounded-lg transition-colors" title="Copy code">
                            {isCopied ? <Check size={18} className="text-green-400" /> : <Copy size={18} />}
                        </button>
                        <button onClick={handleShare} className="p-2 bg-black/30 hover:bg-black/50 rounded-lg transition-colors" title="Share link">
                            <Share2 size={18} />
                        </button>
                    </div>
                </div>
            </div>

            {!user.referredBy && (
                <div className="border-t border-[var(--primary)]/20 pt-4 space-y-2">
                    <p className="text-sm text-gray-300">Have a referral code?</p>
                    <div className="flex gap-2">
                        <input
                            type="text"
                            value={referralCodeInput}
                            onChange={(e) => setReferralCodeInput(e.target.value)}
                            placeholder="Enter code"
                            className="flex-1 bg-black/40 p-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-[var(--primary)] transition"
                        />
                        <GlowingButton onClick={handleApplyCode} className="w-auto px-6 py-3 text-base">Apply</GlowingButton>
                    </div>
                    {message && <p className={`text-center text-sm mt-2 ${message.toLowerCase().includes('success') ? 'text-green-400' : 'text-yellow-400'}`}>{message}</p>}
                </div>
            )}

            <div className="text-center border-t border-[var(--primary)]/20 pt-4">
                <p className="text-lg font-bold">You've referred <span className="text-[var(--accent)]">{user.referralsCount}</span> {user.referralsCount === 1 ? 'friend' : 'friends'}.</p>
                <p className="text-sm text-gray-400">Total bonus earned: <span className="font-bold text-[var(--accent)]">{user.referralBonusEarned.toLocaleString()}</span> coins.</p>
            </div>
        </div>
    );
};

export default ReferralProgram;
